package src;

public class Operator extends Worker {

    public Operator(int salary) {
        super(salary);
    }
}
