<h5 fr-original-style="" style="font-size: 1.25rem; margin-top: 0px; margin-bottom: 0.5rem; color: inherit; line-height: 1.2; font-weight: 500; box-sizing: border-box;">Что нужно сделать</h5>
<li fr-original-style="" style="box-sizing: border-box;">Реализуйте вывод номеров одновременно в несколько файлов из нескольких потоков.</li>
<li fr-original-style="" style="box-sizing: border-box;">Оптимизируйте метод <strong fr-original-style="" style="font-weight: 700; box-sizing: border-box;">padNumber()</strong>.</li>
