public class Main {
    public static void main(String[] args) {
        Arithmetic arithmetic = new Arithmetic(2, 3);
        System.out.println(arithmetic.calcSum());
        System.out.println(arithmetic.calcMultiply());
        System.out.println(arithmetic.maxMin());
    }
}
