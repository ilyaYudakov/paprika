<strong fr-original-style="" style="font-weight: 700; box-sizing: border-box;">Цель</strong>
<li fr-original-style="" style="box-sizing: border-box;">Опробовать принципы работы статических переменных и методов.</li>
<li fr-original-style="" style="box-sizing: border-box;">Научиться самостоятельно создавать статические переменные и реализовывать в классах статические методы.</li>

<strong fr-original-style="" style="font-weight: 700; box-sizing: border-box;">Что нужно сделать</strong>

<p fr-original-style="" style="margin-top: 0px; margin-bottom: 12px; color: var(--ui-sb-color-text-main); box-sizing: border-box; font-size: 16px; line-height: 22px;">Внесите следующие изменения в класс Basket:</p>
<li fr-original-style="" style="box-sizing: border-box;">Добавьте две статические переменные для хранения общей стоимости и общего количества всех товаров во всех корзинах.</li>
<li fr-original-style="" style="box-sizing: border-box;">Реализуйте статические методы, которые будут увеличивать значения этих переменных при добавлении в корзину новых товаров.</li>
<li fr-original-style="" style="box-sizing: border-box;">Реализуйте статический метод расчёта средней цены товара во всех корзинах. Он должен рассчитывать и возвращать отношение общей стоимости всех корзин к общему количеству всех товаров.</li>
<li fr-original-style="" style="box-sizing: border-box;">Реализуйте статический метод расчёта средней стоимости корзины (отношение общей стоимости всех корзин к количеству корзин).</li>
